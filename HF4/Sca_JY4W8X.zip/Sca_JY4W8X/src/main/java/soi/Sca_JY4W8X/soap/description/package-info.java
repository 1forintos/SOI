@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.iit.bme.hu/soi/hw/SeatReservation", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package soi.Sca_JY4W8X.soap.description;

package soi.Sca_JY4W8X.file;

public interface ICinemaFile {
	public void reserveOrBuySeats(String seatsInfoFromFile);
}

package soi.Sca_JY4W8X.jms;

import java.io.StringReader;

import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;

import org.switchyard.component.bean.Reference;
import org.switchyard.component.bean.Service;

import soi.Sca_JY4W8X.rest.ICinemaRest;
import soi.Sca_JY4W8X.rest.Seats;

@Service(ICinemaJms.class)
public class CinemaJms implements ICinemaJms {

	@Inject
	@Reference
	private ICinemaRest restService;
	
	@Override
	public void reserveOrBuySeats(String seatsInfoInJson) {
		System.out.println("Processing msg: " + seatsInfoInJson);
		JsonReader reader = Json.createReader(new StringReader(seatsInfoInJson));
		JsonObject jsonMsg = reader.readObject();
		reader.close();
		
		String type = jsonMsg.getString("type");
		String row = jsonMsg.getString("row");
		String column = jsonMsg.getString("column");
		int count = jsonMsg.getInt("count");
		Seats seatInfo = new Seats();
		seatInfo.setType(type);
		seatInfo.setRow(row);
		seatInfo.setColumn(column);
		seatInfo.setCount(count);
		
		restService.reserveOrBuySeats(seatInfo);
	}

}

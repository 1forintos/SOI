package soi.Sca_JY4W8X.soap.description;


public interface ICinema {

    public LockResponse Lock(
        soi.Sca_JY4W8X.soap.description.Lock parameters) throws ICinemaLockCinemaException;

    public UnlockResponse Unlock(
        soi.Sca_JY4W8X.soap.description.Unlock parameters) throws ICinemaUnlockCinemaException;

    public GetSeatStatusResponse GetSeatStatus(
        soi.Sca_JY4W8X.soap.description.GetSeatStatus parameters) throws ICinemaGetSeatStatusCinemaException;

    public BuyResponse Buy(
        soi.Sca_JY4W8X.soap.description.Buy parameters) throws ICinemaBuyCinemaException;

    public InitResponse Init(
        soi.Sca_JY4W8X.soap.description.Init parameters) throws ICinemaInitCinemaException;

    public GetAllSeatsResponse GetAllSeats(
        soi.Sca_JY4W8X.soap.description.GetAllSeats parameters) throws ICinemaGetAllSeatsCinemaException;

    public ReserveResponse Reserve(
        soi.Sca_JY4W8X.soap.description.Reserve parameters) throws ICinemaReserveCinemaException;
}

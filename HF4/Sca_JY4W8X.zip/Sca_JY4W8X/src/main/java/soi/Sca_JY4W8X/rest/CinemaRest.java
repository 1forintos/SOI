package soi.Sca_JY4W8X.rest;

import javax.inject.Inject;
import javax.ws.rs.core.Response;

import org.switchyard.component.bean.Reference;
import org.switchyard.component.bean.Service;

import soi.Sca_JY4W8X.soap.description.Buy;
import soi.Sca_JY4W8X.soap.description.ICinema;
import soi.Sca_JY4W8X.soap.description.ICinemaBuyCinemaException;
import soi.Sca_JY4W8X.soap.description.ICinemaLockCinemaException;
import soi.Sca_JY4W8X.soap.description.ICinemaReserveCinemaException;
import soi.Sca_JY4W8X.soap.description.Lock;
import soi.Sca_JY4W8X.soap.description.LockResponse;
import soi.Sca_JY4W8X.soap.description.Reserve;
import soi.Sca_JY4W8X.soap.description.Seat;

@Service(ICinemaRest.class)
public class CinemaRest implements ICinemaRest {

	@Inject
	@Reference
	private ICinema soapService;

	@Override
	public Response reserveOrBuySeats(Seats seatOperation) {
		Seat firstSeat = new Seat();
		firstSeat.setRow(seatOperation.getRow());
		firstSeat.setColumn(seatOperation.getColumn());
		Lock lockParams = new Lock();
		lockParams.setSeat(firstSeat);
		lockParams.setCount(seatOperation.getCount());
		LockResponse lockResponse;
		Response resp = null;
		try {
			lockResponse = soapService.Lock(lockParams);
			String lockId = lockResponse.getLockResult();
			System.out.println("Successfull rest lock - lockId: " + lockId);
			if (seatOperation.getType().equals("reserve")) {
				System.out.println("REST reserve");
				try {
					System.out.println("Reserving lock...");
					Reserve reserveParams = new Reserve();
					reserveParams.setLockId(lockId);
					soapService.Reserve(reserveParams);
					System.out.println("Reserved successfully.");
					Result result = new Result();
					result.setLockId(lockId);
					resp = Response.ok(result).build();
				} catch (ICinemaReserveCinemaException e) {
					System.out.println("Reserve error bra'.");
					resp = Response.status(Response.Status.BAD_REQUEST).build();
				}
			} else if (seatOperation.getType().equals("buy")) {
				System.out.println("REST buy");
				try {
					System.out.println("Buying lock...");
					Buy buyParams = new Buy();
					buyParams.setLockId(lockId);
					soapService.Buy(buyParams);
					System.out.println("Bought successfully.");
				} catch (ICinemaBuyCinemaException e) {
					System.out.println("Buy error bra'.");
					resp = Response.status(Response.Status.BAD_REQUEST).build();
				}
			}
			Result result = new Result();
			result.setLockId(lockId);
			resp = Response.ok(result).build();
		} catch (ICinemaLockCinemaException e) {
			System.out.println("Lock error bra'.");
			resp = Response.status(Response.Status.BAD_REQUEST).build();
		}
		return resp;
	}

	// return Response.ok(movieList.getMovieIds(year, sortField)).build();

}

package soi.Sca_JY4W8X.file;

import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObjectBuilder;

import org.switchyard.component.bean.Reference;
import org.switchyard.component.bean.Service;

@Service(ICinemaFile.class)
public class CinemaFile implements ICinemaFile {
	
	@Inject
	@Reference
	private CinemaJmsQueue jmsService;
	
	@Override
	public void reserveOrBuySeats(String seatsInfosFromFile) {
		String[] seatsInfoLines = seatsInfosFromFile.split(System.getProperty("line.separator"));
		for(int i = 0; i < seatsInfoLines.length; i++) {
			String[] propertiesInLine =  seatsInfoLines[i].split("\\s+");
			
			JsonObjectBuilder jsonBuilder = Json.createObjectBuilder();
			jsonBuilder.add("type", propertiesInLine[0]);
			jsonBuilder.add("row", propertiesInLine[1]);
			jsonBuilder.add("column", propertiesInLine[2]);
			jsonBuilder.add("count", Integer.parseInt(propertiesInLine[3]));
			jmsService.reserveOrBuySeat(jsonBuilder.build().toString());
		}
	}
}

package soi.Sca_JY4W8X.soap.definition;

import soi.Sca_JY4W8X.soap.description.Seat;
import soi.Sca_JY4W8X.soap.description.SeatStatus;

public class SeatHandler {
	
	private Seat seat;
	private SeatStatus status;
	
	public SeatHandler(Seat seat) {
		this.seat = seat;
		this.status = SeatStatus.FREE;
	}
	
	public Seat getSeat() {
		return seat;
	}
	
	public SeatStatus getStatus() {
		return status;
	}
	
	public void setStatus(SeatStatus status) {
		this.status = status;
	}
}

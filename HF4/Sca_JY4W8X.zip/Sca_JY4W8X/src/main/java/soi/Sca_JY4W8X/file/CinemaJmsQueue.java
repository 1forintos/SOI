package soi.Sca_JY4W8X.file;

public interface CinemaJmsQueue {
	public void reserveOrBuySeat(String msgInJson);
}

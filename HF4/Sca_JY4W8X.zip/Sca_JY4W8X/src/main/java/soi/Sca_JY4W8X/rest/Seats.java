package soi.Sca_JY4W8X.rest;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType
@XmlRootElement
public class Seats {
	
	@XmlElement
	private String type;
	
	@XmlElement
	private String row;
	
	@XmlElement
	private String column;
	
	@XmlElement
	private int count;
	
	public void setType(String newType) {
		type = newType;
	}
	
	public String getType() {
		return type;
	}
	
	public void setRow(String newRow) {
		row = newRow;
	}
	
	public String getRow() {
		return row;
	}
	
	public void setColumn(String newColumn) {
		column = newColumn;
	}
	
	public String getColumn() {
		return column;
	}
	
	public void setCount(int newCount) {
		count = newCount;
	}
	
	public int getCount() {
		return count;
	}
}

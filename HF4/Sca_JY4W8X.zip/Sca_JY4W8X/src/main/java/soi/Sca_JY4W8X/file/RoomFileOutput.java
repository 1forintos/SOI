package soi.Sca_JY4W8X.file;

public interface RoomFileOutput {
	public void saveRoomStatus(String roomStatus);
}

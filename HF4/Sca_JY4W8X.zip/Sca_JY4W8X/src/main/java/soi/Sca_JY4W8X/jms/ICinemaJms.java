package soi.Sca_JY4W8X.jms;


public interface ICinemaJms {
	public void reserveOrBuySeats(String seatsInfoInJson);
}

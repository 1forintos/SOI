package soi.Sca_JY4W8X.soap.definition;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.dom.DOMResult;

import org.switchyard.annotations.Transformer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import soi.Sca_JY4W8X.soap.description.Buy;
import soi.Sca_JY4W8X.soap.description.BuyResponse;
import soi.Sca_JY4W8X.soap.description.GetAllSeats;
import soi.Sca_JY4W8X.soap.description.GetAllSeatsResponse;
import soi.Sca_JY4W8X.soap.description.GetSeatStatus;
import soi.Sca_JY4W8X.soap.description.GetSeatStatusResponse;
import soi.Sca_JY4W8X.soap.description.ICinemaBuyCinemaException;
import soi.Sca_JY4W8X.soap.description.ICinemaGetAllSeatsCinemaException;
import soi.Sca_JY4W8X.soap.description.ICinemaGetSeatStatusCinemaException;
import soi.Sca_JY4W8X.soap.description.ICinemaInitCinemaException;
import soi.Sca_JY4W8X.soap.description.ICinemaLockCinemaException;
import soi.Sca_JY4W8X.soap.description.ICinemaReserveCinemaException;
import soi.Sca_JY4W8X.soap.description.ICinemaUnlockCinemaException;
import soi.Sca_JY4W8X.soap.description.Init;
import soi.Sca_JY4W8X.soap.description.InitResponse;
import soi.Sca_JY4W8X.soap.description.Lock;
import soi.Sca_JY4W8X.soap.description.LockResponse;
import soi.Sca_JY4W8X.soap.description.Reserve;
import soi.Sca_JY4W8X.soap.description.ReserveResponse;
import soi.Sca_JY4W8X.soap.description.Unlock;
import soi.Sca_JY4W8X.soap.description.UnlockResponse;

public final class CinemaTransformer {

	private Element marshal(QName qname, Object obj) throws JAXBException {
		JAXBContext ctx = JAXBContext.newInstance(obj.getClass());
		Marshaller marshaller = ctx.createMarshaller();
		JAXBElement jaxbElem = new JAXBElement(qname, obj.getClass(), obj);
		DOMResult res = new DOMResult();
		marshaller.marshal(jaxbElem, res);
		Element elem = ((Document) res.getNode()).getDocumentElement();
		return elem;
	}

	private <T> T unmarshal(Element elem, Class<T> cls) throws JAXBException {
		JAXBContext ctx = JAXBContext.newInstance(cls);
		Unmarshaller unmarshaller = ctx.createUnmarshaller();
		return unmarshaller.unmarshal(elem, cls).getValue();
	}
	
	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}BuyResponse")
	public Element transformBuyResponseToBuyResponse(BuyResponse from) throws JAXBException {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
			"BuyResponse"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}GetAllSeatsResponse")
	public Element transformGetAllSeatsResponseToGetAllSeatsResponse(
			GetAllSeatsResponse from) throws JAXBException {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"GetAllSeatsResponse"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}GetSeatStatusResponse")
	public Element transformGetSeatStatusResponseToGetSeatStatusResponse(
			GetSeatStatusResponse from) throws JAXBException {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"GetSeatStatusResponse"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}CinemaException")
	public Element transformICinemaBuyCinemaExceptionToCinemaException(
			ICinemaBuyCinemaException from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"CinemaException"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}CinemaException")
	public Element transformICinemaGetAllSeatsCinemaExceptionToCinemaException(
			ICinemaGetAllSeatsCinemaException from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"CinemaException"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}CinemaException")
	public Element transformICinemaGetSeatStatusCinemaExceptionToCinemaException(
			ICinemaGetSeatStatusCinemaException from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"CinemaException"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}CinemaException")
	public Element transformICinemaInitCinemaExceptionToCinemaException(
			ICinemaInitCinemaException from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"CinemaException"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}CinemaException")
	public Element transformICinemaLockCinemaExceptionToCinemaException(
			ICinemaLockCinemaException from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"CinemaException"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}CinemaException")
	public Element transformICinemaReserveCinemaExceptionToCinemaException(
			ICinemaReserveCinemaException from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"CinemaException"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}CinemaException")
	public Element transformICinemaUnlockCinemaExceptionToCinemaException(
			ICinemaUnlockCinemaException from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"CinemaException"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}InitResponse")
	public Element transformInitResponseToInitResponse(InitResponse from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"InitResponse"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}LockResponse")
	public Element transformLockResponseToLockResponse(LockResponse from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"LockResponse"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}ReserveResponse")
	public Element transformReserveResponseToReserveResponse(
			ReserveResponse from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"ReserveResponse"), from);
	}

	@Transformer(to = "{http://www.iit.bme.hu/soi/hw/SeatReservation}UnlockResponse")
	public Element transformUnlockResponseToUnlockResponse(UnlockResponse from) throws JAXBException  {
		return marshal(new QName("http://www.iit.bme.hu/soi/hw/SeatReservation",
				"UnlockResponse"), from);
	}

	@Transformer(from = "{http://www.iit.bme.hu/soi/hw/SeatReservation}Buy")
	public Buy transformBuyToBuy(Element from) throws JAXBException {
		return unmarshal(from, Buy.class);
	}

	@Transformer(from = "{http://www.iit.bme.hu/soi/hw/SeatReservation}GetAllSeats")
	public GetAllSeats transformGetAllSeatsToGetAllSeats(Element from) throws JAXBException {
		return unmarshal(from, GetAllSeats.class);
	}

	@Transformer(from = "{http://www.iit.bme.hu/soi/hw/SeatReservation}GetSeatStatus")
	public GetSeatStatus transformGetSeatStatusToGetSeatStatus(Element from)throws JAXBException {
		return unmarshal(from, GetSeatStatus.class);
	}

	@Transformer(from = "{http://www.iit.bme.hu/soi/hw/SeatReservation}Init")
	public Init transformInitToInit(Element from) throws JAXBException {
		return unmarshal(from, Init.class);
	}

	@Transformer(from = "{http://www.iit.bme.hu/soi/hw/SeatReservation}Lock")
	public Lock transformLockToLock(Element from) throws JAXBException {
		return unmarshal(from, Lock.class);
	}

	@Transformer(from = "{http://www.iit.bme.hu/soi/hw/SeatReservation}Reserve")
	public Reserve transformReserveToReserve(Element from) throws JAXBException {
		return unmarshal(from, Reserve.class);
	}

	@Transformer(from = "{http://www.iit.bme.hu/soi/hw/SeatReservation}Unlock")
	public Unlock transformUnlockToUnlock(Element from) throws JAXBException {
		return unmarshal(from, Unlock.class);
	}

}

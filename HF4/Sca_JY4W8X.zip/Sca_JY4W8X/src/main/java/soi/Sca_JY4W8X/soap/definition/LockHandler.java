package soi.Sca_JY4W8X.soap.definition;

import soi.Sca_JY4W8X.soap.description.Lock;
import soi.Sca_JY4W8X.soap.description.Seat;

public class LockHandler {
	
	private String id;
	private Lock lock;
	
	public LockHandler(Lock lock) {
		this.lock = lock;
		id = lock.getSeat().getRow() + "_" 
			+ lock.getSeat().getColumn() + "_"
			+ lock.getCount();
	}
	
	public String getId() {
		return id;
	}
	
	public Seat getSeat() {
		return lock.getSeat();
	}
	
	public int getCount() {
		return lock.getCount();
	}
}

package seatreservation;

public enum SeatStatus {
	free,
	locked,
	reserved
}
